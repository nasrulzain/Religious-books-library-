import { useState, useEffect } from 'react'
import { RELIGIONS, LANGUAGES } from './lib/constants.js'
import { getSetting, setSetting } from './lib/db.js'
import HomeView from './views/HomeView.jsx'
import ReligionView from './views/ReligionView.jsx'
import BookView from './views/BookView.jsx'
import ReaderView from './views/ReaderView.jsx'
import DownloadManager from './components/DownloadManager.jsx'

// ─── Global styles ────────────────────────────────────────────────────────────
const GLOBAL_CSS = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  html, body {
    font-family: 'Source Sans 3', system-ui, sans-serif;
    background: #f5f3ef;
    color: #1a1a1a;
    height: 100%;
    overscroll-behavior: none;
    -webkit-tap-highlight-color: transparent;
  }

  #root { height: 100%; }

  ::-webkit-scrollbar { width: 3px; height: 3px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: #d0cdc8; border-radius: 4px; }

  button { font-family: inherit; }

  .press { transition: transform .12s ease, opacity .12s ease; cursor: pointer; }
  .press:active { transform: scale(.96); opacity: .85; }

  .fade-in { animation: fadeIn .25s ease; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

  .shimmer {
    background: linear-gradient(90deg, #ece9e3 25%, #e0ddd7 50%, #ece9e3 75%);
    background-size: 300% 100%;
    animation: shimAnim 1.6s infinite;
    border-radius: 6px;
  }
  @keyframes shimAnim { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }

  .verse-row { border-left: 3px solid transparent; padding-left: 14px; transition: border-color .2s; }
  .verse-row:hover { border-left-color: var(--accent); }

  @media (max-width: 480px) {
    .hide-mobile { display: none !important; }
  }
`

export default function App() {
  // ─── Navigation stack ────────────────────────────────────────────────────
  const [screen, setScreen]       = useState('home')
  const [religion, setReligion]   = useState(null)
  const [book, setBook]           = useState(null)
  const [readerCtx, setReaderCtx] = useState(null)
  // For Bible sub-navigation
  const [bibleBook, setBibleBook] = useState(null)

  // ─── Settings ────────────────────────────────────────────────────────────
  const [lang, setLang]           = useState(() => LANGUAGES[0])
  const [fontSize, setFontSize]   = useState(16)
  const [showDownload, setShowDownload] = useState(false)

  // Load saved settings on mount
  useEffect(() => {
    getSetting('langCode', 'en').then(code => {
      const found = LANGUAGES.find(l => l.code === code)
      if (found) setLang(found)
    })
    getSetting('fontSize', 16).then(setFontSize)
  }, [])

  // Save language preference
  const changeLang = (code) => {
    const found = LANGUAGES.find(l => l.code === code)
    if (found) {
      setLang(found)
      setSetting('langCode', code)
    }
  }

  const changeFontSize = (size) => {
    setFontSize(size)
    setSetting('fontSize', size)
  }

  // ─── Navigation helpers ──────────────────────────────────────────────────
  const goHome = () => {
    setScreen('home')
    setReligion(null)
    setBook(null)
    setReaderCtx(null)
    setBibleBook(null)
  }

  const goReligion = (r) => {
    setReligion(r)
    setBook(null)
    setReaderCtx(null)
    setBibleBook(null)
    setScreen('religion')
  }

  const goBook = (b) => {
    setBook(b)
    setReaderCtx(null)
    setBibleBook(null)
    setScreen('book')
  }

  const goReader = (ctx) => {
    setReaderCtx(ctx)
    setScreen('reader')
  }

  const goBack = () => {
    if (screen === 'reader') {
      setScreen('book')
      setReaderCtx(null)
    } else if (screen === 'book') {
      if ((book?.type === 'bible_ot' || book?.type === 'bible_nt') && bibleBook) {
        setBibleBook(null)
      } else {
        setScreen('religion')
        setBook(null)
        setBibleBook(null)
      }
    } else if (screen === 'religion') {
      goHome()
    }
  }

  const accent = religion?.accent || '#333333'

  return (
    <div style={{ minHeight: '100vh', background: '#f5f3ef', '--accent': accent }}>
      <style>{GLOBAL_CSS}</style>

      {/* ── HEADER ── */}
      <header style={{
        background: '#fff',
        borderBottom: '1px solid #e5e2dc',
        height: 56,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 16px',
        position: 'sticky',
        top: 0,
        zIndex: 100,
        boxShadow: '0 1px 6px rgba(0,0,0,.05)',
        gap: 8,
      }}>
        {/* Left: back + logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0, flex: 1 }}>
          {screen !== 'home' && (
            <button
              className="press"
              onClick={goBack}
              style={{
                background: '#f0ede8',
                border: 'none',
                borderRadius: 8,
                padding: '6px 11px',
                fontSize: 13,
                fontWeight: 600,
                color: '#444',
                cursor: 'pointer',
                flexShrink: 0,
                display: 'flex',
                alignItems: 'center',
                gap: 3,
              }}
            >
              ← Back
            </button>
          )}
          <div
            onClick={goHome}
            style={{ display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer', minWidth: 0 }}
          >
            <span style={{ fontSize: 20, flexShrink: 0 }}>📖</span>
            <span style={{
              fontFamily: "'Lora', serif",
              fontSize: 16,
              fontWeight: 700,
              color: '#1a1a1a',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}>
              Sacred Scriptures
            </span>
          </div>
        </div>

        {/* Right: language + download */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
          <select
            value={lang.code}
            onChange={e => changeLang(e.target.value)}
            style={{
              appearance: 'none',
              background: '#f5f3ef',
              border: '1px solid #ddd',
              borderRadius: 8,
              padding: '5px 9px',
              fontSize: 12,
              fontFamily: 'inherit',
              color: '#333',
              fontWeight: 500,
              cursor: 'pointer',
              outline: 'none',
              maxWidth: 120,
            }}
          >
            {LANGUAGES.map(l => (
              <option key={l.code} value={l.code}>{l.name}</option>
            ))}
          </select>

          <button
            className="press"
            onClick={() => setShowDownload(true)}
            title="Download for Offline"
            style={{
              background: accent,
              border: 'none',
              borderRadius: 8,
              padding: '6px 10px',
              color: '#fff',
              fontSize: 14,
              cursor: 'pointer',
            }}
          >
            ⬇
          </button>
        </div>
      </header>

      {/* ── SCREENS ── */}
      {screen === 'home' && (
        <HomeView religions={RELIGIONS} onSelect={goReligion} />
      )}
      {screen === 'religion' && religion && (
        <ReligionView religion={religion} onBook={goBook} />
      )}
      {screen === 'book' && book && religion && (
        <BookView
          book={book}
          religion={religion}
          lang={lang}
          bibleBook={bibleBook}
          setBibleBook={setBibleBook}
          onSection={goReader}
        />
      )}
      {screen === 'reader' && readerCtx && book && religion && (
        <ReaderView
          ctx={readerCtx}
          book={book}
          religion={religion}
          lang={lang}
          fontSize={fontSize}
          onFontSize={changeFontSize}
        />
      )}

      {/* ── DOWNLOAD MANAGER ── */}
      {showDownload && (
        <DownloadManager
          religions={RELIGIONS}
          languages={LANGUAGES}
          onClose={() => setShowDownload(false)}
        />
      )}
    </div>
  )
}
