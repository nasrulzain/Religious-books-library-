import { SURAHS, BIBLE_OT, BIBLE_NT, SECTIONS } from '../lib/constants.js'

export default function BookView({ book, religion, lang, bibleBook, setBibleBook, onSection }) {
  const type = book.type

  // ── QURAN: list all 114 surahs ──────────────────────────────────────────
  if (type === 'quran') {
    return (
      <PageWrapper>
        <PageHeader
          title={book.name}
          sub={`${book.meta} · Select a Surah`}
          accent={religion.accent}
        />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {SURAHS.map(s => (
            <SurahRow
              key={s.n}
              surah={s}
              accent={religion.accent}
              bg={religion.bg}
              border={religion.border}
              onClick={() => onSection({ surahNum: s.n, title: `${s.name} — ${s.en}` })}
            />
          ))}
        </div>
      </PageWrapper>
    )
  }

  // ── BIBLE OT / NT: first show book list, then chapters ──────────────────
  if (type === 'bible_ot' || type === 'bible_nt') {
    const bookList = type === 'bible_ot' ? BIBLE_OT : BIBLE_NT

    if (!bibleBook) {
      return (
        <PageWrapper>
          <PageHeader
            title={book.name}
            sub={`${bookList.length} books · Select a book`}
            accent={religion.accent}
          />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            {bookList.map(b => (
              <ChapterRow
                key={b.name}
                label={b.name}
                sub={`${b.chapters} chapter${b.chapters > 1 ? 's' : ''}`}
                accent={religion.accent}
                border={religion.border}
                onClick={() => setBibleBook(b)}
              />
            ))}
          </div>
        </PageWrapper>
      )
    }

    // Show chapters of selected Bible book
    return (
      <PageWrapper>
        <PageHeader
          title={bibleBook.name}
          sub={`${bibleBook.chapters} chapters · Select a chapter`}
          accent={religion.accent}
        />
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(72px, 1fr))',
          gap: 8,
        }}>
          {Array.from({ length: bibleBook.chapters }, (_, i) => i + 1).map(ch => (
            <div
              key={ch}
              className="press"
              onClick={() => onSection({
                title: `${bibleBook.name} — Chapter ${ch}`,
                bibleBook: bibleBook.name,
                chapter: ch,
              })}
              style={{
                background: '#fff',
                borderRadius: 9,
                padding: '12px 6px',
                border: `1px solid ${religion.border}`,
                textAlign: 'center',
                cursor: 'pointer',
              }}
            >
              <div style={{ fontSize: 12, fontWeight: 700, color: religion.accent }}>Ch {ch}</div>
            </div>
          ))}
        </div>
      </PageWrapper>
    )
  }

  // ── BIBLE single book (e.g. Psalms in Judaism) ──────────────────────────
  if (type === 'bible_single') {
    return (
      <PageWrapper>
        <PageHeader
          title={book.name}
          sub={`${book.chapters} chapters · Select a chapter`}
          accent={religion.accent}
        />
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(72px, 1fr))',
          gap: 8,
        }}>
          {Array.from({ length: book.chapters }, (_, i) => i + 1).map(ch => (
            <div
              key={ch}
              className="press"
              onClick={() => onSection({
                title: `${book.bibleBook} ${ch}`,
                bibleBook: book.bibleBook,
                chapter: ch,
              })}
              style={{
                background: '#fff',
                borderRadius: 9,
                padding: '12px 6px',
                border: `1px solid ${religion.border}`,
                textAlign: 'center',
                cursor: 'pointer',
              }}
            >
              <div style={{ fontSize: 12, fontWeight: 700, color: religion.accent }}>{ch}</div>
            </div>
          ))}
        </div>
      </PageWrapper>
    )
  }

  // ── AI-based books: show sections ────────────────────────────────────────
  if (type === 'ai') {
    const sectionList = SECTIONS[book.sections] || []
    return (
      <PageWrapper>
        <PageHeader
          title={book.name}
          sub={book.meta || 'Select a section to read'}
          accent={religion.accent}
        />
        {sectionList.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#aaa', fontSize: 14 }}>
            No sections defined.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {sectionList.map(s => (
              <ChapterRow
                key={s.n}
                num={s.n}
                label={s.title}
                sub={s.sub}
                accent={religion.accent}
                bg={religion.bg}
                border={religion.border}
                onClick={() => onSection({ title: s.title, sectionNum: s.n })}
              />
            ))}
          </div>
        )}
      </PageWrapper>
    )
  }

  return null
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function PageWrapper({ children }) {
  return (
    <div className="fade-in" style={{ maxWidth: 680, margin: '0 auto', padding: '24px 14px 60px' }}>
      {children}
    </div>
  )
}

function PageHeader({ title, sub, accent }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{
        fontFamily: "'Lora', serif",
        fontSize: 22,
        fontWeight: 700,
        color: '#1a1a1a',
        lineHeight: 1.25,
      }}>
        {title}
      </div>
      {sub && (
        <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>{sub}</div>
      )}
      <div style={{ width: 36, height: 3, background: accent, borderRadius: 2, marginTop: 10 }} />
    </div>
  )
}

function SurahRow({ surah, accent, bg, border, onClick }) {
  return (
    <div
      className="press"
      onClick={onClick}
      style={{
        background: '#fff',
        borderRadius: 9,
        padding: '10px 14px',
        border: `1px solid ${border}`,
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        cursor: 'pointer',
      }}
    >
      <div style={{
        width: 36,
        height: 36,
        background: bg,
        borderRadius: 8,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 12,
        fontWeight: 700,
        color: accent,
        flexShrink: 0,
      }}>
        {surah.n}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{
          fontFamily: "'Lora', serif",
          fontSize: 14.5,
          fontWeight: 700,
          color: '#1a1a1a',
        }}>
          {surah.name}
        </div>
        <div style={{ fontSize: 12, color: '#888' }}>
          {surah.en} · {surah.v} verses
        </div>
      </div>
      <div style={{ fontSize: 18, color: '#ccc' }}>›</div>
    </div>
  )
}

function ChapterRow({ num, label, sub, accent, bg, border, onClick }) {
  return (
    <div
      className="press"
      onClick={onClick}
      style={{
        background: '#fff',
        borderRadius: 10,
        padding: '12px 16px',
        border: `1px solid ${border || '#e8e6e2'}`,
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        cursor: 'pointer',
      }}
    >
      {num !== undefined && (
        <div style={{
          width: 36,
          height: 36,
          background: bg || '#f5f3ef',
          borderRadius: 8,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 13,
          fontWeight: 700,
          color: accent,
          flexShrink: 0,
        }}>
          {num}
        </div>
      )}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: "'Lora', serif", fontSize: 15, fontWeight: 700, color: '#1a1a1a' }}>
          {label}
        </div>
        {sub && <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{sub}</div>}
      </div>
      <div style={{ fontSize: 18, color: '#ccc', flexShrink: 0 }}>›</div>
    </div>
  )
}
