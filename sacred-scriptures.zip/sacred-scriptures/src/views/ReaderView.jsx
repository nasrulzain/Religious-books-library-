import { useState, useEffect, useRef } from 'react'
import { SECTIONS } from '../lib/constants.js'
import { loadVerses } from '../lib/api.js'

export default function ReaderView({ ctx, book, religion, lang, fontSize, onFontSize }) {
  const [verses, setVerses]     = useState([])
  const [loading, setLoading]   = useState(true)
  const [error, setError]       = useState(null)
  const [showControls, setShowControls] = useState(false)
  const topRef = useRef(null)

  const isRTL = lang.rtl
  const isQuran = book.type === 'quran'

  useEffect(() => {
    setLoading(true)
    setError(null)
    setVerses([])

    topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })

    let cancelled = false

    async function load() {
      try {
        // Build context for the loader
        const sectionsList = book.sections ? SECTIONS[book.sections] : []
        const extraContext = {
          bibleBook: ctx.bibleBook,
          chapter: ctx.chapter,
          sectionNum: ctx.sectionNum,
          sections: sectionsList,
          religionName: religion.name,
        }

        const result = await loadVerses(
          book,
          ctx.surahNum || ctx.sectionNum || ctx.chapter || 1,
          lang.code,
          extraContext
        )

        if (!cancelled) {
          setVerses(result)
          setLoading(false)
        }
      } catch (e) {
        if (!cancelled) {
          setError(e.message || 'Failed to load')
          setLoading(false)
        }
      }
    }

    load()
    return () => { cancelled = true }
  }, [ctx, lang.code])

  return (
    <div ref={topRef} style={{ maxWidth: 700, margin: '0 auto', padding: '24px 16px 80px' }}>

      {/* ── Reader header ── */}
      <div style={{
        marginBottom: 24,
        paddingBottom: 14,
        borderBottom: `2px solid ${religion.accent}`,
      }} className="fade-in">
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          marginBottom: 6,
          flexWrap: 'wrap',
        }}>
          <span style={{ fontSize: 16 }}>{religion.symbol}</span>
          <span style={{ fontSize: 12.5, color: '#888', fontWeight: 500 }}>
            {religion.name} · {book.name}
          </span>
        </div>

        <div style={{
          fontFamily: "'Lora', serif",
          fontSize: 22,
          fontWeight: 700,
          color: '#1a1a1a',
          lineHeight: 1.3,
          marginBottom: 4,
        }}>
          {ctx.title}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 12, color: '#aaa' }}>
            Reading in: <strong style={{ color: religion.accent }}>{lang.name}</strong>
          </div>

          {/* Font size controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <button
              className="press"
              onClick={() => onFontSize(Math.max(12, fontSize - 1))}
              style={{ ...btnStyle, fontSize: 14, fontWeight: 700 }}
            >
              A−
            </button>
            <button
              className="press"
              onClick={() => onFontSize(Math.min(26, fontSize + 1))}
              style={{ ...btnStyle, fontSize: 14, fontWeight: 700 }}
            >
              A+
            </button>
          </div>
        </div>
      </div>

      {/* ── Loading ── */}
      {loading && <LoadingSkeleton accent={religion.accent} />}

      {/* ── Error ── */}
      {!loading && error && (
        <div style={{
          background: '#fff5f5',
          border: '1px solid #fcc',
          borderRadius: 10,
          padding: '18px 16px',
          color: '#c00',
          fontSize: 14,
          lineHeight: 1.6,
        }}>
          <strong>Could not load scripture.</strong>
          <br />
          {navigator.onLine
            ? `Error: ${error}`
            : 'You are offline. Please download this content first by tapping ⬇ in the header.'}
        </div>
      )}

      {/* ── Verses ── */}
      {!loading && !error && verses.length > 0 && (
        <div className="fade-in" style={{ direction: isRTL ? 'rtl' : 'ltr' }}>

          {/* Bismillah for Quran (except Surah 9 and Surah 1 which starts differently) */}
          {isQuran && ctx.surahNum !== 9 && (
            <div style={{
              textAlign: 'center',
              fontFamily: "'Lora', serif",
              fontSize: 24,
              color: religion.accent,
              margin: '0 0 28px',
              padding: '12px 0 16px',
              borderBottom: `1px solid ${religion.border}`,
              direction: 'rtl',
            }}>
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ
              {lang.code !== 'ar' && (
                <div style={{
                  fontSize: 13,
                  color: '#888',
                  marginTop: 6,
                  fontFamily: "'Source Sans 3', sans-serif",
                  direction: 'ltr',
                  fontStyle: 'italic',
                }}>
                  In the name of Allah, the Most Gracious, the Most Merciful
                </div>
              )}
            </div>
          )}

          {/* Verse list */}
          {verses.map((verse, i) => (
            <VerseBlock
              key={verse.n}
              verse={verse}
              isQuran={isQuran}
              isRTL={isRTL}
              langCode={lang.code}
              accent={religion.accent}
              bg={religion.bg}
              border={religion.border}
              fontSize={fontSize}
              delay={Math.min(i * 0.02, 0.35)}
            />
          ))}

          {/* End marker */}
          <div style={{
            textAlign: 'center',
            marginTop: 48,
            fontSize: 13,
            color: '#bbb',
            fontStyle: 'italic',
          }}>
            ✦ End of {ctx.title} ✦
          </div>
        </div>
      )}

      {/* Empty state */}
      {!loading && !error && verses.length === 0 && (
        <div style={{ textAlign: 'center', padding: 48, color: '#aaa', fontSize: 14 }}>
          No content found. Please check your connection.
        </div>
      )}
    </div>
  )
}

// ─── Verse block ─────────────────────────────────────────────────────────────

function VerseBlock({ verse, isQuran, isRTL, langCode, accent, bg, border, fontSize, delay }) {
  return (
    <div
      className="verse-row fade-in"
      style={{
        marginBottom: isQuran ? 28 : 18,
        animationDelay: `${delay}s`,
        '--accent': accent,
      }}
    >
      <div style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: 12,
        flexDirection: isRTL ? 'row-reverse' : 'row',
      }}>
        {/* Verse number badge */}
        <div style={{
          flexShrink: 0,
          width: 32,
          height: 32,
          borderRadius: '50%',
          background: bg,
          border: `1px solid ${border}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 11,
          fontWeight: 700,
          color: accent,
          marginTop: 3,
        }}>
          {verse.n}
        </div>

        <div style={{ flex: 1 }}>
          {/* Arabic text (Quran only) */}
          {isQuran && verse.arabic && (
            <div style={{
              fontFamily: "'Lora', serif",
              fontSize: langCode === 'ar' ? fontSize + 4 : fontSize + 2,
              lineHeight: 1.9,
              color: '#111',
              direction: 'rtl',
              textAlign: 'right',
              marginBottom: verse.text ? 10 : 0,
            }}>
              {verse.arabic}
            </div>
          )}

          {/* Translation / text */}
          {(verse.text || (!isQuran)) && (
            <div style={{
              fontFamily: "'Lora', serif",
              fontSize,
              lineHeight: 1.85,
              color: '#2a2a2a',
              direction: isRTL && !isQuran ? 'rtl' : 'ltr',
              textAlign: isRTL && !isQuran ? 'right' : 'left',
              fontStyle: isQuran ? 'italic' : 'normal',
            }}>
              {verse.text}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Loading skeleton ─────────────────────────────────────────────────────────

function LoadingSkeleton({ accent }) {
  return (
    <div>
      <div style={{
        display: 'flex',
        gap: 5,
        justifyContent: 'center',
        marginBottom: 24,
      }}>
        {[1, 2, 3].map(i => (
          <div
            key={i}
            style={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              background: accent,
              opacity: 0.4,
              animation: `pulse 1.2s ease ${(i - 1) * 0.2}s infinite`,
            }}
          />
        ))}
        <style>{`
          @keyframes pulse { 0%,100%{opacity:.3} 50%{opacity:1} }
        `}</style>
      </div>

      {Array.from({ length: 7 }).map((_, i) => (
        <div key={i} style={{ marginBottom: 24, display: 'flex', gap: 12 }}>
          <div className="shimmer" style={{ width: 32, height: 32, borderRadius: '50%', flexShrink: 0 }} />
          <div style={{ flex: 1 }}>
            <div className="shimmer" style={{ height: 14, width: '90%', marginBottom: 7 }} />
            <div className="shimmer" style={{ height: 14, width: `${60 + Math.random() * 30}%` }} />
          </div>
        </div>
      ))}
    </div>
  )
}

const btnStyle = {
  background: '#f0ede8',
  border: '1px solid #ddd',
  borderRadius: 7,
  padding: '4px 9px',
  cursor: 'pointer',
  color: '#555',
  fontSize: 12,
}
