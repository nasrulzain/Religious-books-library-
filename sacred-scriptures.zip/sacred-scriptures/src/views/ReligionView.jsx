export default function ReligionView({ religion, onBook }) {
  const primary = religion.books.filter(b => b.primary)
  const secondary = religion.books.filter(b => !b.primary)

  return (
    <div style={{ maxWidth: 680, margin: '0 auto', padding: '24px 14px 60px' }}>
      {/* Religion header */}
      <div
        className="fade-in"
        style={{
          background: religion.accent,
          borderRadius: 14,
          padding: '22px 20px',
          color: '#fff',
          marginBottom: 24,
          display: 'flex',
          alignItems: 'center',
          gap: 16,
        }}
      >
        <div style={{ fontSize: 44 }}>{religion.symbol}</div>
        <div>
          <div style={{ fontFamily: "'Lora', serif", fontSize: 24, fontWeight: 700, lineHeight: 1.2 }}>
            {religion.name}
          </div>
          {religion.native && (
            <div style={{ fontSize: 14, opacity: 0.75, marginTop: 2 }}>{religion.native}</div>
          )}
          <div style={{ fontSize: 13, opacity: 0.8, marginTop: 5, fontStyle: 'italic' }}>
            {religion.tagline}
          </div>
        </div>
      </div>

      {/* Primary scripture */}
      <SectionLabel label="Primary Scripture" color={religion.accent} />
      {primary.map(b => (
        <BookRow key={b.id} book={b} religion={religion} onClick={() => onBook(b)} />
      ))}

      {/* Secondary texts */}
      {secondary.length > 0 && (
        <>
          <SectionLabel label="Secondary Texts & Collections" color="#888" top />
          {secondary.map(b => (
            <BookRow key={b.id} book={b} religion={religion} onClick={() => onBook(b)} />
          ))}
        </>
      )}
    </div>
  )
}

function SectionLabel({ label, color, top }) {
  return (
    <div style={{
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '.1em',
      textTransform: 'uppercase',
      color,
      marginTop: top ? 24 : 0,
      marginBottom: 10,
      paddingBottom: 6,
      borderBottom: `1px solid ${color}33`,
    }}>
      {label}
    </div>
  )
}

function BookRow({ book, religion, onClick }) {
  return (
    <div
      className="press"
      onClick={onClick}
      style={{
        background: '#fff',
        borderRadius: 10,
        padding: '14px 16px',
        marginBottom: 8,
        border: `1px solid ${religion.border}`,
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        cursor: 'pointer',
      }}
    >
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontFamily: "'Lora', serif",
          fontSize: 16,
          fontWeight: 700,
          color: '#1a1a1a',
          marginBottom: book.native ? 2 : 4,
        }}>
          {book.name}
        </div>
        {book.native && (
          <div style={{ fontSize: 12.5, color: religion.accent, opacity: 0.8, marginBottom: 4 }}>
            {book.native}
          </div>
        )}
        <div style={{ fontSize: 13, color: '#666', lineHeight: 1.5 }}>{book.desc}</div>
        {book.meta && (
          <div style={{ fontSize: 11, color: religion.accent, fontWeight: 600, marginTop: 5, opacity: 0.85 }}>
            {book.meta}
          </div>
        )}
      </div>
      <div style={{ fontSize: 22, color: '#ccc', flexShrink: 0 }}>›</div>
    </div>
  )
}
