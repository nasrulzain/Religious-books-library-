export default function HomeView({ religions, onSelect }) {
  const islam = religions[0]
  const others = religions.slice(1)

  return (
    <div style={{ maxWidth: 860, margin: '0 auto', padding: '24px 14px 60px' }}>
      {/* Hero */}
      <div style={{ textAlign: 'center', marginBottom: 28 }} className="fade-in">
        <div style={{
          fontFamily: "'Lora', serif",
          fontSize: 28,
          fontWeight: 700,
          color: '#1a1a1a',
          lineHeight: 1.25,
          marginBottom: 8,
        }}>
          World Sacred Scriptures
        </div>
        <div style={{ fontSize: 14.5, color: '#777', maxWidth: 480, margin: '0 auto' }}>
          Read the holy books of every major world religion.
          Select a language from the top right. Download for offline use.
        </div>
      </div>

      {/* Islam — featured */}
      <div
        className="press fade-in"
        onClick={() => onSelect(islam)}
        style={{
          background: islam.accent,
          borderRadius: 16,
          padding: '22px 20px',
          color: '#fff',
          marginBottom: 14,
          display: 'flex',
          alignItems: 'center',
          gap: 18,
          boxShadow: `0 4px 24px ${islam.accent}44`,
          cursor: 'pointer',
        }}
      >
        <div style={{ fontSize: 46, lineHeight: 1 }}>{islam.symbol}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
            <span style={{ fontFamily: "'Lora', serif", fontSize: 24, fontWeight: 700 }}>
              {islam.name}
            </span>
            <span style={{ fontSize: 15, opacity: 0.8, direction: 'rtl' }}>{islam.native}</span>
          </div>
          <div style={{ fontSize: 13.5, opacity: 0.85, margin: '4px 0 10px' }}>{islam.tagline}</div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {islam.books.map(b => (
              <span
                key={b.id}
                style={{
                  background: 'rgba(255,255,255,.18)',
                  borderRadius: 20,
                  padding: '3px 10px',
                  fontSize: 11.5,
                  fontWeight: 500,
                }}
              >
                {b.name}
              </span>
            ))}
          </div>
        </div>
        <div style={{ fontSize: 24, opacity: 0.55, flexShrink: 0 }}>›</div>
      </div>

      {/* Other religions — 2 col grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
        gap: 12,
      }}>
        {others.map((r, i) => (
          <div
            key={r.id}
            className="press fade-in"
            onClick={() => onSelect(r)}
            style={{
              background: '#fff',
              borderRadius: 12,
              padding: '18px',
              border: `1px solid ${r.border}`,
              cursor: 'pointer',
              animationDelay: `${i * 0.05}s`,
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
              <div style={{
                width: 44,
                height: 44,
                background: r.bg,
                borderRadius: 10,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 22,
                border: `1px solid ${r.border}`,
                flexShrink: 0,
              }}>
                {r.symbol}
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{
                  fontFamily: "'Lora', serif",
                  fontSize: 17,
                  fontWeight: 700,
                  color: '#1a1a1a',
                }}>
                  {r.name}
                </div>
                {r.native && (
                  <div style={{ fontSize: 11.5, color: r.accent, opacity: 0.85 }}>{r.native}</div>
                )}
              </div>
            </div>
            <div style={{ fontSize: 13, color: '#666', marginBottom: 10, lineHeight: 1.5 }}>
              {r.tagline}
            </div>
            <div style={{ fontSize: 11.5, color: r.accent, fontWeight: 600 }}>
              {r.books.length} sacred text{r.books.length > 1 ? 's' : ''} →
            </div>
          </div>
        ))}
      </div>

      {/* Footer note */}
      <div style={{
        textAlign: 'center',
        marginTop: 32,
        fontSize: 12,
        color: '#aaa',
        lineHeight: 1.6,
      }}>
        Tap ⬇ in the header to download scriptures for offline reading.<br />
        Supports 20 languages. Quran available in 11 native translations.
      </div>
    </div>
  )
}
