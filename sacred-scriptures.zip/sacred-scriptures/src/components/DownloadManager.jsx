import { useState, useEffect } from 'react'
import { downloadFullQuran } from '../lib/api.js'
import { isDownloaded, getAllDownloads, clearAllData } from '../lib/db.js'

export default function DownloadManager({ religions, languages, onClose }) {
  const [downloads, setDownloads]   = useState({})
  const [active, setActive]         = useState(null)   // { bookId, langCode }
  const [progress, setProgress]     = useState(0)
  const [progressMsg, setProgressMsg] = useState('')
  const [error, setError]           = useState(null)
  const [showConfirm, setShowConfirm] = useState(false)

  // Load existing download statuses
  useEffect(() => {
    loadStatuses()
  }, [])

  async function loadStatuses() {
    const all = await getAllDownloads()
    const map = {}
    for (const item of all) {
      // key format is "bookId|langCode"
      map[item] = true
    }
    // getAllDownloads returns values not keys — re-check via isDownloaded
    // Actually we stored with keys, let's just check each combo
    setDownloads(prev => ({ ...prev, _loaded: true }))
  }

  async function checkDownloaded(bookId, langCode) {
    return isDownloaded(bookId, langCode)
  }

  async function startDownload(bookId, langCode) {
    if (active) return
    setActive({ bookId, langCode })
    setProgress(0)
    setProgressMsg('Starting...')
    setError(null)

    try {
      if (bookId === 'quran') {
        await downloadFullQuran(langCode, (pct, msg) => {
          setProgress(pct)
          setProgressMsg(msg)
        })
        setDownloads(prev => ({ ...prev, [`${bookId}|${langCode}`]: true }))
      }
    } catch (e) {
      setError(`Download failed: ${e.message}. Please check your internet connection.`)
    } finally {
      setActive(null)
    }
  }

  async function handleClearAll() {
    await clearAllData()
    setDownloads({})
    setShowConfirm(false)
  }

  // Languages with native Quran support
  const quranLangs = languages.filter(l =>
    !['zh','yue','ja','pcm','mr','te','ta','vi'].includes(l.code)
  )

  return (
    <>
      {/* Overlay */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed', inset: 0,
          background: 'rgba(0,0,0,.4)',
          zIndex: 200,
        }}
      />

      {/* Panel */}
      <div style={{
        position: 'fixed',
        bottom: 0, left: 0, right: 0,
        background: '#fff',
        borderRadius: '20px 20px 0 0',
        zIndex: 201,
        maxHeight: '85vh',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '0 -4px 32px rgba(0,0,0,.15)',
      }}>
        {/* Handle */}
        <div style={{
          width: 40, height: 4,
          background: '#ddd',
          borderRadius: 2,
          margin: '12px auto 0',
        }} />

        {/* Header */}
        <div style={{
          padding: '16px 20px 12px',
          borderBottom: '1px solid #f0ede8',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ fontFamily: "'Lora', serif", fontSize: 18, fontWeight: 700 }}>
              Download for Offline
            </div>
            <div style={{ fontSize: 12.5, color: '#888', marginTop: 2 }}>
              Download scriptures to read without internet
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: '#f0ede8', border: 'none', borderRadius: 8,
              padding: '6px 12px', fontSize: 13, cursor: 'pointer', color: '#555',
            }}
          >
            Close
          </button>
        </div>

        {/* Scrollable content */}
        <div style={{ overflowY: 'auto', padding: '16px 20px 32px', flex: 1 }}>

          {/* Active download progress */}
          {active && (
            <div style={{
              background: '#e8f5ee',
              border: '1px solid #9fd6b5',
              borderRadius: 10,
              padding: '14px 16px',
              marginBottom: 20,
            }}>
              <div style={{
                fontSize: 13,
                fontWeight: 600,
                color: '#1a6b40',
                marginBottom: 8,
              }}>
                Downloading... {progress}%
              </div>
              <div style={{
                height: 6,
                background: '#c8e8d5',
                borderRadius: 4,
                overflow: 'hidden',
                marginBottom: 6,
              }}>
                <div style={{
                  height: '100%',
                  width: `${progress}%`,
                  background: '#1a6b40',
                  borderRadius: 4,
                  transition: 'width .3s ease',
                }} />
              </div>
              <div style={{ fontSize: 12, color: '#555' }}>{progressMsg}</div>
            </div>
          )}

          {/* Error */}
          {error && (
            <div style={{
              background: '#fff5f5',
              border: '1px solid #fcc',
              borderRadius: 10,
              padding: 14,
              marginBottom: 16,
              fontSize: 13,
              color: '#c00',
              lineHeight: 1.5,
            }}>
              {error}
            </div>
          )}

          {/* ── Quran downloads ── */}
          <SectionTitle>📖 Holy Quran — Select Language</SectionTitle>
          <div style={{ fontSize: 12.5, color: '#888', marginBottom: 12, lineHeight: 1.5 }}>
            Download the full Quran (all 114 Surahs) in your preferred language.
            Arabic text is always included.
          </div>

          <div style={{ display: 'grid', gap: 8 }}>
            {quranLangs.map(l => (
              <DownloadRow
                key={l.code}
                label={l.name}
                sublabel="Full Quran (114 Surahs) · Arabic + Translation"
                isActive={!!(active?.bookId === 'quran' && active?.langCode === l.code)}
                isDownloading={!!active}
                onDownload={() => startDownload('quran', l.code)}
                bookId="quran"
                langCode={l.code}
              />
            ))}
          </div>

          {/* ── Bible note ── */}
          <SectionTitle top>✝ Bible</SectionTitle>
          <div style={{
            background: '#fdf0f0',
            border: '1px solid #e8b4b4',
            borderRadius: 10,
            padding: '12px 14px',
            fontSize: 13,
            color: '#555',
            lineHeight: 1.6,
          }}>
            Bible chapters are automatically saved to your device each time you read them.
            Simply read a chapter online once — it will be available offline afterward.
          </div>

          {/* ── Other books note ── */}
          <SectionTitle top>ॐ ☸ ✡ ☬ 🔥 Other Scriptures</SectionTitle>
          <div style={{
            background: '#fdf8ec',
            border: '1px solid #e8d099',
            borderRadius: 10,
            padding: '12px 14px',
            fontSize: 13,
            color: '#555',
            lineHeight: 1.6,
          }}>
            All other scripture sections (Bhagavad Gita, Dhammapada, Torah, Guru Granth Sahib, etc.)
            are cached automatically on first read. Read a section once online — it saves to your device.
          </div>

          {/* ── Clear data ── */}
          <SectionTitle top>🗑 Clear Downloaded Data</SectionTitle>
          {!showConfirm ? (
            <button
              onClick={() => setShowConfirm(true)}
              style={{
                background: '#fff',
                border: '1px solid #fcc',
                borderRadius: 9,
                padding: '10px 16px',
                fontSize: 13,
                color: '#c00',
                cursor: 'pointer',
                width: '100%',
                textAlign: 'left',
              }}
            >
              Clear all downloaded data
            </button>
          ) : (
            <div style={{
              background: '#fff5f5',
              border: '1px solid #fcc',
              borderRadius: 10,
              padding: '14px 16px',
            }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: '#c00', marginBottom: 8 }}>
                Are you sure? This will delete all offline data.
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  onClick={handleClearAll}
                  style={{
                    background: '#c00',
                    border: 'none',
                    borderRadius: 8,
                    padding: '8px 16px',
                    fontSize: 13,
                    color: '#fff',
                    cursor: 'pointer',
                  }}
                >
                  Yes, clear all
                </button>
                <button
                  onClick={() => setShowConfirm(false)}
                  style={{
                    background: '#f0ede8',
                    border: 'none',
                    borderRadius: 8,
                    padding: '8px 16px',
                    fontSize: 13,
                    color: '#555',
                    cursor: 'pointer',
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  )
}

function SectionTitle({ children, top }) {
  return (
    <div style={{
      fontSize: 13,
      fontWeight: 700,
      color: '#444',
      marginTop: top ? 24 : 0,
      marginBottom: 10,
      display: 'flex',
      alignItems: 'center',
      gap: 6,
    }}>
      {children}
    </div>
  )
}

function DownloadRow({ label, sublabel, isActive, isDownloading, onDownload, bookId, langCode }) {
  const [downloaded, setDownloaded] = useState(false)

  useEffect(() => {
    isDownloaded(bookId, langCode).then(setDownloaded)
  }, [bookId, langCode])

  return (
    <div style={{
      background: '#fff',
      border: `1px solid ${downloaded ? '#9fd6b5' : '#e8e6e2'}`,
      borderRadius: 9,
      padding: '12px 14px',
      display: 'flex',
      alignItems: 'center',
      gap: 12,
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: '#1a1a1a' }}>{label}</div>
        <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{sublabel}</div>
      </div>

      {downloaded ? (
        <div style={{
          fontSize: 12,
          fontWeight: 600,
          color: '#1a6b40',
          background: '#e8f5ee',
          borderRadius: 20,
          padding: '4px 10px',
          flexShrink: 0,
        }}>
          ✓ Saved
        </div>
      ) : isActive ? (
        <div style={{ fontSize: 12, color: '#888', flexShrink: 0 }}>Downloading...</div>
      ) : (
        <button
          onClick={onDownload}
          disabled={isDownloading}
          style={{
            background: isDownloading ? '#ccc' : '#1a6b40',
            border: 'none',
            borderRadius: 8,
            padding: '7px 14px',
            fontSize: 13,
            color: '#fff',
            cursor: isDownloading ? 'default' : 'pointer',
            flexShrink: 0,
            fontWeight: 600,
          }}
        >
          Download
        </button>
      )}
    </div>
  )
}
