# 📖 Sacred Scriptures — Complete Setup Guide

Follow these steps **exactly in order**. Takes about 20–30 minutes total.
Everything is **100% free**.

---

## WHAT YOU NEED BEFORE STARTING

- A phone or any device with internet
- An email address

---

## STEP 1 — Create a GitHub Account (5 minutes)

GitHub is where you will store your app's code.

1. Open your browser and go to: **https://github.com**
2. Click **Sign up**
3. Enter your email, create a password, choose a username
4. Verify your email
5. You now have a GitHub account ✅

---

## STEP 2 — Create a Vercel Account (2 minutes)

Vercel will host your app online for free.

1. Go to: **https://vercel.com**
2. Click **Sign Up**
3. Choose **Continue with GitHub**
4. Authorize Vercel to access your GitHub
5. You now have a Vercel account ✅

---

## STEP 3 — Create a New GitHub Repository (3 minutes)

1. Go to **https://github.com**
2. Click the **+** button in the top right
3. Click **New repository**
4. Name it: `sacred-scriptures`
5. Make sure it is set to **Public**
6. Check ✅ **Add a README file**
7. Click **Create repository**

---

## STEP 4 — Upload ALL the App Files to GitHub (10 minutes)

You need to upload the files in the correct folder structure.
Follow this EXACTLY.

### The folder structure you must create:

```
sacred-scriptures/
├── package.json
├── vite.config.js
├── vercel.json
├── index.html
├── public/
│   └── icons/
│       └── icon.svg
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── lib/
    │   ├── constants.js
    │   ├── db.js
    │   └── api.js
    └── views/
        ├── HomeView.jsx
        ├── ReligionView.jsx
        ├── BookView.jsx
        └── ReaderView.jsx
    └── components/
        └── DownloadManager.jsx
```

### How to upload files on GitHub (mobile):

1. Go to your repository on GitHub
2. Click **Add file** → **Create new file**
3. In the "Name your file" box, type the path like: `src/main.jsx`
   - GitHub will automatically create the folders!
4. Paste the file content in the big text box below
5. Scroll down, click **Commit new file**
6. Repeat for EVERY file

### Upload these files in this order:

**File 1:** Name: `package.json`
**File 2:** Name: `vite.config.js`
**File 3:** Name: `vercel.json`
**File 4:** Name: `index.html`
**File 5:** Name: `public/icons/icon.svg`
**File 6:** Name: `src/main.jsx`
**File 7:** Name: `src/App.jsx`
**File 8:** Name: `src/lib/constants.js`
**File 9:** Name: `src/lib/db.js`
**File 10:** Name: `src/lib/api.js`
**File 11:** Name: `src/views/HomeView.jsx`
**File 12:** Name: `src/views/ReligionView.jsx`
**File 13:** Name: `src/views/BookView.jsx`
**File 14:** Name: `src/views/ReaderView.jsx`
**File 15:** Name: `src/components/DownloadManager.jsx`

---

## STEP 5 — Deploy on Vercel (3 minutes)

1. Go to **https://vercel.com/dashboard**
2. Click **Add New** → **Project**
3. Find your `sacred-scriptures` repository and click **Import**
4. In the configuration screen:
   - **Framework Preset**: Select **Vite**
   - Leave everything else as default
5. Click **Deploy**
6. Wait 2–3 minutes for it to build
7. You will see a green **Congratulations!** screen
8. Click **Visit** to open your app

Your app is now live at something like:
`https://sacred-scriptures-abc123.vercel.app`

---

## STEP 6 — Install as App on Your Phone (1 minute)

To use it offline like a real app:

**On Android (Chrome):**
1. Open your Vercel URL in Chrome
2. Tap the 3 dots menu (⋮) in the top right
3. Tap **Add to Home screen**
4. Tap **Add**
5. The app icon will appear on your home screen!

**On iPhone (Safari):**
1. Open your Vercel URL in Safari
2. Tap the Share button (square with arrow)
3. Scroll down and tap **Add to Home Screen**
4. Tap **Add**

---

## STEP 7 — Download Scriptures for Offline (5 minutes)

1. Open the app (must have internet for this step)
2. Tap the **⬇** button in the top right header
3. Select a language (e.g. English)
4. Tap **Download** next to the Quran
5. Wait for the download to complete (1–2 minutes)
6. After download: you can read the Quran OFFLINE, no internet needed!

### How other books go offline:
- **Bible**: Read any chapter once online → it saves automatically
- **Bhagavad Gita, Dhammapada, Torah, etc.**: Same — read once, saved forever

---

## HOW THE APP WORKS

### For users:
1. Open the app
2. Select a religion
3. Select a book
4. Select a chapter/surah/section
5. Read the actual text, verse by verse

### Languages:
- Change language anytime from the dropdown in the header
- For Quran: 11 languages have native translations (Arabic, English, Urdu, Hindi, French, German, Indonesian, Turkish, Bengali, Russian, Spanish)
- For other books: AI generates content in any of the 20 languages

### Offline:
- Download Quran in your language using the ⬇ button
- All other content saves automatically after first read

---

## TROUBLESHOOTING

**App shows blank page?**
- Check all files were uploaded correctly
- Check the Vercel deployment logs for errors

**Quran not loading?**
- Check internet connection
- The AlQuran.cloud API must be reachable

**Download not working?**
- Try a different network
- Make sure you have storage space on your phone

**"Failed to load" error?**
- You may be offline and haven't downloaded yet
- Use internet to read the section once first

---

## SHARING YOUR APP

Share your Vercel URL with anyone in the world:
`https://your-app-name.vercel.app`

They can:
- Open it in any browser
- Install it on their phone
- Read every religious text
- Download for offline

---

## ADDING CUSTOM DOMAIN (Optional, Free)

1. Go to Vercel → Your project → Settings → Domains
2. Add your domain (e.g. `sacredscriptures.in`)
3. Or get a free domain at **https://www.freenom.com** (.tk, .ml domains)

---

## COST SUMMARY

| Service | Cost |
|---------|------|
| GitHub hosting | FREE |
| Vercel deployment | FREE |
| AlQuran.cloud API | FREE |
| Bible API (bible-api.com) | FREE |
| Anthropic AI API (for other books) | FREE via Claude.ai |
| **TOTAL** | **₹0** |

---

*Built with React + Vite + IndexedDB. Deployed on Vercel. 7 religions · 40+ texts · 20 languages.*
